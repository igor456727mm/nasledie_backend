<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145345_router_like_update extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('z_router_like', 'id_region');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
