<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145343_days_object_update extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->dropColumn('z_router_day_object', 'description');
        $this->addColumn('z_router_day_object', 'description', 'text default  null ');



    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
