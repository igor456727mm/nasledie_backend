<?php

use yii\db\Migration;

/**
 * Class m200901_230214_router_object
 */
class m200901_230214_router_object extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {



    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('z_router_object');

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200901_230214_router_object cannot be reverted.\n";

        return false;
    }
    */
}
