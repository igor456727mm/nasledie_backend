<?php

use yii\db\Migration;

/**
 * Class m200904_131927_router_name_update
 */
class m200904_131927_router_name_update extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->alterColumn('z_router', 'name', 'varchar(255)');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200904_131927_router_name_update cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200904_131927_router_name_update cannot be reverted.\n";

        return false;
    }
    */
}
