<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145350_ball extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('z_ball', [
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->notNull(),
            'description' => $this->text()->defaultValue(null),
            'ball' => $this->string(255)->defaultValue(null),
            'status' => $this->integer(1)->defaultValue(0),
        ]);
        $this->createTable('z_router_ball', [
            'id' => $this->primaryKey(),
            'router_id' => $this->integer(11)->notNull(),
            'ball_id' => $this->integer(11)->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
