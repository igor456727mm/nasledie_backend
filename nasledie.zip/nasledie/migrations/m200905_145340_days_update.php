<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145340_days_update extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->addColumn('z_router_day_object', 'startPointCoordLat', 'varchar(255) default null');
        $this->addColumn('z_router_day_object', 'startPointCoordLong', 'varchar(255) default null');
        $this->addColumn('z_router_day_object', 'description', 'text default null');
        $this->addColumn('z_router_day_object', 'image', 'text default null');
        $this->addColumn('z_router', 'kml', 'text default null');


    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
