<?php

use yii\db\Migration;

/**
 * Class m200901_223920_route
 */
class m200901_223920_route extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('z_router', [
            'id' => $this->primaryKey(),
            'name' => $this->string(12)->notNull()->unique(),
            'description' => $this->text()->defaultValue(null),
            'startPoint' => $this->string(255)->defaultValue(null),
            'startPointCoord' => $this->string(255)->defaultValue(null),
            'dateStart' => $this->date()->defaultValue(null),
            'timeStart' => $this->string(255)->defaultValue(null),
            'endPoint' => $this->string(255)->defaultValue(null),
            'endPointCoord' => $this->string(255)->defaultValue(null),
            'typeMovement' => $this->string(255)->defaultValue(null),
            'isGeoRoute' => $this->integer(1)->defaultValue(0),
            'user_id' => $this->integer(11)->notNull(),
            'date_create' => $this->date()->notNull(),

        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('z_router');

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200901_223920_route cannot be reverted.\n";

        return false;
    }
    */
}
