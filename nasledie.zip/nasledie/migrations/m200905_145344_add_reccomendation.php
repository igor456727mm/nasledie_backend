<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145344_add_reccomendation extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->addColumn('z_router', 'recommendation', 'integer(1) default 0');



    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
