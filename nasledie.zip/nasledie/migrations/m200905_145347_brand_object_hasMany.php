<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145347_brand_object_hasMany extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('z_brand_object_relation', [
            'id' => $this->primaryKey(),
            'brand_id' => $this->integer(11)->notNull(),
            'object_id' => $this->integer(11)->notNull(),
        ]);
        $this->dropColumn('z_brand_object', 'brand_id');

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
