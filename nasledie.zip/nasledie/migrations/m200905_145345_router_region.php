<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145345_router_region extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->createTable('z_router_region', [
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->notNull(),
        ]);
        $this->createTable('z_router_region_relation', [
            'id' => $this->primaryKey(),
            'id_router' => $this->integer(11)->notNull(),
            'id_region' => $this->integer(11)->notNull(),
        ]);

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
