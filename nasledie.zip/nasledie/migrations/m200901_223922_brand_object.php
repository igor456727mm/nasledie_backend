<?php

use yii\db\Migration;

/**
 * Class m200901_223920_route
 */
class m200901_223922_brand_object extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('z_brand_object', [
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->defaultValue(null),
            'short_description' => $this->text()->defaultValue(null),
            'description' => $this->text()->defaultValue(null),
            'lat' => $this->float()->defaultValue(null),
            'long' => $this->float()->defaultValue(null),
            'brand_id' => $this->integer(11)->notNull(),
            'image' => $this->string(255)->defaultValue(null),
            'user_id' => $this->integer(11)->notNull(),
            'date_create' => $this->date()->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('z_brand_object');

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200901_223920_route cannot be reverted.\n";

        return false;
    }
    */
}
