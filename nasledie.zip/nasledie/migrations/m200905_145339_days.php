<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145339_days extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->dropColumn('z_router_object', 'timeInWay');
        $this->dropColumn('z_router_object', 'way');
        $this->dropColumn('z_router_object', 'stopTime');
        $this->dropColumn('z_router_object', 'time');

        $this->createTable('z_router_day', [
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->defaultValue(null),
            'startPoint' => $this->string(255)->defaultValue(null),
            'startPointCoordLat' => $this->float()->defaultValue(null),
            'startPointCoordLong' => $this->float()->defaultValue(null),
            'dateStart' => $this->string(255)->defaultValue(null),
            'timeStart' => $this->string(255)->defaultValue(null),
            'endPoint' => $this->string(255)->defaultValue(null),
            'endPointCoordLat' => $this->float()->defaultValue(null),
            'endPointCoordLong' => $this->float()->defaultValue(null),
            'dateEnd' => $this->string(255)->defaultValue(null),
            'timeEnd' => $this->string(255)->defaultValue(null),
            'router_id' => $this->integer(11)->notNull(),
        ]);
        $this->createTable('z_router_day_object', [
            'id' => $this->primaryKey(),
            'name' => $this->string(255)->defaultValue(null),
            'timeInWay' => $this->integer(11)->defaultValue(null),
            'way' => $this->integer(11)->defaultValue(null),
            'stopTime' => $this->integer(11)->defaultValue(null),
            'time' => $this->integer(11)->defaultValue(null),
            'day_id' => $this->integer(11)->notNull(),
        ]);
        $this->createTable('z_router_day_object_type', [
            'id' => $this->primaryKey(),
            'type' => $this->string(255)->defaultValue(null),
            'day_object_id' => $this->integer(11)->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
