<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145337_add_days extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        
        $this->addColumn('z_router', 'dateEnd', 'string(255) default null ');
        $this->alterColumn('z_router', 'dateStart', 'varchar(255) default null ');
        $this->addColumn('z_router', 'timeEnd', 'string(255) default null ');


        $this->addColumn('z_router_object', 'timeInWay', 'integer(11) default null ');
        $this->addColumn('z_router_object', 'way', 'integer(11) default null ');
        $this->addColumn('z_router_object', 'stopTime', 'integer(11) default null ');
        $this->addColumn('z_router_object', 'time', 'integer(11) default null ');

        $this->createTable('z_router_object_type', [
            'id' => $this->primaryKey(),
            'type' => $this->string(255)->notNull(),
            'object_id' => $this->integer(11)->notNull(),
            'router_id' => $this->integer(11)->notNull()
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
