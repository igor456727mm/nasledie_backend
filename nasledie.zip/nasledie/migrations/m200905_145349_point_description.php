<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145347_brand_object_hasMany extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('z_router', 'startPointDescription', 'text default null');
        $this->addColumn('z_router', 'endPointDescription', 'text default null');


    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
