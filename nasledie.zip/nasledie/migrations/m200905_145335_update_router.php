<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145335_update_router extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('z_router', 'totalWay', 'integer(11)');
        $this->addColumn('z_router', 'content', 'text');
        $this->addColumn('z_router', 'totalTime', 'integer(11)');
        $this->createTable('z_router_type', [
            'id' => $this->primaryKey(),
            'type' => $this->string(255)->notNull(),
            'router_id' => $this->integer(11)->notNull()
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
