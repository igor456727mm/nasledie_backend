<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145342_days_object_update extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('z_router_day_object', 'startPointCoordLat');
        $this->dropColumn('z_router_day_object', 'startPointCoordLong');
        $this->addColumn('z_router_day_object', 'startPointCoordLat', 'float default null');
        $this->addColumn('z_router_day_object', 'startPointCoordLong', 'float default null');



    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
