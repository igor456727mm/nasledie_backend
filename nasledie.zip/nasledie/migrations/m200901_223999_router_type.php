<?php

use yii\db\Migration;

/**
 * Class m200901_223920_route
 */
class m200901_223999_router_type extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('z_router_tag', [
            'id' => $this->primaryKey(),
            'name' => $this->string(12)->notNull(),
        ]);
        $this->createTable('z_router_tag_relation', [
            'id' => $this->primaryKey(),
            'id_router' => $this->integer(11)->notNull(),
            'id_tag' => $this->integer(11)->notNull(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('z_router');

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200901_223920_route cannot be reverted.\n";

        return false;
    }
    */
}
