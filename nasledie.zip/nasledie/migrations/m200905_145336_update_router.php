<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145336_update_router extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->addColumn('z_router', 'startPointCoordLat', 'integer(11)');
        $this->addColumn('z_router', 'startPointCoordLong', 'integer(11)');
        $this->addColumn('z_router', 'endPointCoordLat', 'integer(11)');
        $this->addColumn('z_router', 'endPointCoordLong', 'integer(11)');
        $this->dropColumn('z_router', 'startPointCoord');
        $this->dropColumn('z_router', 'endPointCoord');
        $this->createTable('z_router_file', [
            'id' => $this->primaryKey(),
            'url' => $this->string(255),
            'base64' => $this->text(),
            'type' => $this->string(255)->notNull(),
            'router_id' => $this->integer(11)->notNull(),
        ]);
       
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
