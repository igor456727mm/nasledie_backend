<?php

use yii\db\Migration;

/**
 * Class m200905_145335_update_router
 */
class m200905_145338_update_coords extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {

        $this->alterColumn('z_router', 'startPointCoordLat', 'FLOAT');
        $this->alterColumn('z_router', 'startPointCoordLong', 'FLOAT');
        $this->alterColumn('z_router', 'endPointCoordLat', 'FLOAT');
        $this->alterColumn('z_router', 'endPointCoordLong', 'FLOAT');

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200905_145335_update_router cannot be reverted.\n";

        return false;
    }
    */
}
