<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_region".
 *
 * @property int $id
 * @property string|null $code
 * @property string|null $name
 * @property string|null $geo_name
 */
class ZRegion extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_region';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code'], 'string', 'max' => 3],
            [['name', 'geo_name'], 'string', 'max' => 300],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'name' => Yii::t('app', 'Name'),
            'geo_name' => Yii::t('app', 'Geo Name'),
        ];
    }
}
