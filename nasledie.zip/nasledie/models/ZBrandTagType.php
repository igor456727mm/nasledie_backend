<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_tag_type".
 *
 * @property int|null $brand_id
 * @property string|null $name
 */
class ZBrandTagType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_tag_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['brand_id'], 'default', 'value' => null],
            [['brand_id'], 'integer'],
            [['name'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'brand_id' => Yii::t('app', 'Brand ID'),
            'name' => Yii::t('app', 'Name'),
        ];
    }
}
