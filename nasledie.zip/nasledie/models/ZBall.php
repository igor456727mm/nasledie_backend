<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_ball".
 *
 * @property int $id
 * @property string|null $name
 * @property string|null $description
 * @property int|null $ball
 * @property int $status
 * @property string|null $code
 */
class ZBall extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_ball';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'status'], 'required'],
            [['id', 'ball', 'status'], 'default', 'value' => null],
            [['id', 'ball', 'status'], 'integer'],
            [['name', 'description', 'code'], 'string'],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'description' => Yii::t('app', 'Description'),
            'ball' => Yii::t('app', 'Ball'),
            'status' => Yii::t('app', 'Status'),
            'code' => Yii::t('app', 'Code'),
        ];
    }
}
