<?php

namespace app\models;

use Yii;
use app\models\ZRouterDay;
use app\models\ZRouterDayObjectType;

/**
 * This is the model class for table "z_router_day_object".
 *
 * @property int $id
 * @property string|null $name
 * @property int|null $timeInWay
 * @property int|null $way
 * @property int|null $stopTime
 * @property int|null $time
 * @property int $day_id
 */
class ZRouterDayObject extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_day_object';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['timeInWay', 'way', 'stopTime', 'time', 'day_id', 'object_id'], 'default', 'value' => null],
            [['timeInWay', 'way', 'stopTime', 'time', 'day_id', 'object_id', 'way_false'], 'integer'],
            [['day_id'], 'required'],
            [['startPointCoordLat','startPointCoordLong',], 'safe'],
            [['name', 'image' ], 'string', 'max' => 255],
            [['description' ], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'timeInWay' => Yii::t('app', 'Time In Way'),
            'way' => Yii::t('app', 'Way'),
            'stopTime' => Yii::t('app', 'Stop Time'),
            'time' => Yii::t('app', 'Time'),
            'day_id' => Yii::t('app', 'Day ID'),
            'object_id' => Yii::t('app', 'object_id'),
            'startPointCoordLat' => Yii::t('app', 'startPointCoordLat'),
            'startPointCoordLong' => Yii::t('app', 'startPointCoordLong'),
            'description' => Yii::t('app', 'description'),
            'image' => Yii::t('app', 'image'),
            'way_false' => Yii::t('app', 'way_false'),
        ];
    }

    public function getDay()
    {
        return $this->hasOne(ZRouterDay::className(), ['id' => 'router_id']);
    }
    public function getTypes()
    {
        return $this->hasMany(ZRouterDayObjectType::className(), ['day_object_id' => 'id']);
    }
}
