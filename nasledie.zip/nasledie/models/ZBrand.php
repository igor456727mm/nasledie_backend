<?php

namespace app\models;

use Yii;
use app\models\ZBrandTagType;
/**
 * This is the model class for table "z_brand".
 *
 * @property int $id
 * @property string|null $dttm_add
 * @property string|null $dttm_save
 * @property int|null $owner_user_id
 * @property string|null $name
 * @property string|null $type
 * @property int|null $status
 * @property string|null $time_appearance
 * @property string|null $contact_fio
 * @property string|null $contact_email
 * @property string|null $contact_phone
 * @property string|null $youtube
 * @property string|null $block1
 * @property string|null $block2
 * @property string|null $block3
 * @property string|null $block4
 * @property string|null $position
 * @property string|null $route
 * @property int|null $state
 * @property string|null $anons
 * @property int|null $zoom
 * @property int|null $subtype
 * @property int|null $main
 * @property string|null $author
 * @property string|null $img_thumb_position
 * @property int|null $views
 * @property int|null $comments
 * @property int|null $rating_cnt
 * @property int|null $rating_val
 * @property int|null $rating
 * @property int|null $checkin_cnt
 * @property int|null $favorites_cnt
 * @property int|null $use_seo
 *
 * @property ZBrandRequest[] $zBrandRequests
 */
class ZBrand extends \yii\db\ActiveRecord
{
    public $region = '';
    public $images = [];
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['dttm_add', 'dttm_save'], 'safe'],
            [['owner_user_id', 'status', 'state', 'zoom', 'subtype', 'main', 'views', 'comments', 'rating_cnt', 'rating_val', 'rating', 'checkin_cnt', 'favorites_cnt', 'use_seo'], 'default', 'value' => null],
            [['owner_user_id', 'status', 'state', 'zoom', 'subtype', 'main', 'views', 'comments', 'rating_cnt', 'rating_val', 'rating', 'checkin_cnt', 'favorites_cnt', 'use_seo'], 'integer'],
            [['block1', 'block2', 'block3', 'block4', 'route', 'anons'], 'string'],
            [['name', 'time_appearance', 'contact_fio', 'contact_email', 'contact_phone', 'youtube', 'position'], 'string', 'max' => 255],
            [['type'], 'string', 'max' => 20],
            [['author'], 'string', 'max' => 200],
            [['img_thumb_position'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'dttm_add' => Yii::t('app', 'Dttm Add'),
            'dttm_save' => Yii::t('app', 'Dttm Save'),
            'owner_user_id' => Yii::t('app', 'Owner User ID'),
            'name' => Yii::t('app', 'Name'),
            'type' => Yii::t('app', 'Type'),
            'status' => Yii::t('app', 'Status'),
            'time_appearance' => Yii::t('app', 'Time Appearance'),
            'contact_fio' => Yii::t('app', 'Contact Fio'),
            'contact_email' => Yii::t('app', 'Contact Email'),
            'contact_phone' => Yii::t('app', 'Contact Phone'),
            'youtube' => Yii::t('app', 'Youtube'),
            'block1' => Yii::t('app', 'Block1'),
            'block2' => Yii::t('app', 'Block2'),
            'block3' => Yii::t('app', 'Block3'),
            'block4' => Yii::t('app', 'Block4'),
            'position' => Yii::t('app', 'Position'),
            'route' => Yii::t('app', 'Route'),
            'state' => Yii::t('app', 'State'),
            'anons' => Yii::t('app', 'Anons'),
            'zoom' => Yii::t('app', 'Zoom'),
            'subtype' => Yii::t('app', 'Subtype'),
            'main' => Yii::t('app', 'Main'),
            'author' => Yii::t('app', 'Author'),
            'img_thumb_position' => Yii::t('app', 'Img Thumb Position'),
            'views' => Yii::t('app', 'Views'),
            'comments' => Yii::t('app', 'Comments'),
            'rating_cnt' => Yii::t('app', 'Rating Cnt'),
            'rating_val' => Yii::t('app', 'Rating Val'),
            'rating' => Yii::t('app', 'Rating'),
            'checkin_cnt' => Yii::t('app', 'Checkin Cnt'),
            'favorites_cnt' => Yii::t('app', 'Favorites Cnt'),
            'use_seo' => Yii::t('app', 'Use Seo'),
        ];
    }

    /**
     * Gets query for [[ZBrandRequests]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getZBrandRequests()
    {
        return $this->hasMany(ZBrandRequest::className(), ['brand_fk' => 'id']);
    }
    public function getTags()
    {
        return $this->hasMany(ZBrandTagType::className(), ['brand_id' => 'id']);
    }
}
