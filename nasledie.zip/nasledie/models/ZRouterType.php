<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_router_type".
 *
 * @property int $id
 * @property string $type
 * @property int $router_id
 */
class ZRouterType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['type', 'router_id'], 'required'],
            [['router_id'], 'default', 'value' => null],
            [['router_id'], 'integer'],
            [['type'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type' => Yii::t('app', 'Type'),
            'router_id' => Yii::t('app', 'Router ID'),
        ];
    }
}
