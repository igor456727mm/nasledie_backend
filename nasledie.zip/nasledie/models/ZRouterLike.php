<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_router_like".
 *
 * @property int $id
 * @property int $id_router
 * @property int $id_region
 * @property int $id_user
 */
class ZRouterLike extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_like';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_router',  'id_user'], 'required'],
            [['id_router',  'id_user'], 'default', 'value' => null],
            [['id_router',  'id_user'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'id_router' => Yii::t('app', 'Id Router'),
            'id_user' => Yii::t('app', 'Id User'),
        ];
    }
}
