<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_router_object_type".
 *
 * @property int $id
 * @property string $type
 * @property int $object_id
 * @property int $router_id
 */
class ZRouterObjectType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_object_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['type', 'object_id', 'router_id'], 'required'],
            [['object_id', 'router_id'], 'default', 'value' => null],
            [['object_id', 'router_id'], 'integer'],
            [['type'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type' => Yii::t('app', 'Type'),
            'object_id' => Yii::t('app', 'Object ID'),
            'router_id' => Yii::t('app', 'Router ID'),
        ];
    }
}
