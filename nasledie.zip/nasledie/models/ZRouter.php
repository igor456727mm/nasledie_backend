<?php

namespace app\models;

use Yii;
use app\models\ZRouterType;
use app\models\ZRouterFile;
use yii\helpers\ArrayHelper;
use app\models\ZRouterDay;
use app\models\ZRouterObject;
use app\models\ZRouterLike;
use app\models\ZRouterTag;
use app\models\ZRouterTagRelation;
use app\models\ZRegion;
use app\models\ZRouterRegionRelation;
use app\models\ZRouterDayObjectType;
/**
 * This is the model class for table "z_router".
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string|null $startPoint
 * @property string|null $startPointCoord
 * @property string|null $dateStart
 * @property string|null $timeStart
 * @property string|null $endPoint
 * @property string|null $endPointCoord
 * @property string|null $typeMovement
 * @property int|null $isGeoRoute
 * @property int $user_id
 * @property string $date_create
 */
class ZRouter extends \yii\db\ActiveRecord
{
    public $objects = [];
    public $files = [];
    public $typesOfMovement = [];
    public $pointStart = [];
    public $pointEnd = [];
    const PATHIMAGE = 'https://zhivoe-nasledie.ga/photos/brand/';
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router';
    }
    public function beforeSave($insert)
    {

        if (parent::beforeSave($insert)) {

            return true;
        } else {
            return false;
        }
    }
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'user_id', 'date_create'], 'required'],
            [['description', 'name', 'content', 'kml'], 'string'],
            [['dateStart', 'date_create', 'dateEnd', 'startPointCoordLat', 'startPointCoordLong', 'endPointCoordLat', 'endPointCoordLong', 'map_points' ], 'safe'],
            [['isGeoRoute', 'user_id'], 'default', 'value' => null],
            [['isGeoRoute', 'user_id', 'totalTime', 'totalWay', 'recommendation', 'parent_id'], 'integer'],
            [['startPoint',  'timeStart', 'timeEnd', 'endPoint'], 'string', 'max' => 255],
            //[['name'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'description' => Yii::t('app', 'Description'),
            'startPoint' => Yii::t('app', 'Start Point'),
            'endPointDescription' => Yii::t('app', 'Start Point'),
            'startPointCoordLat' => Yii::t('app', 'startPointCoordLat'),
            'startPointCoordLong' => Yii::t('app', 'startPointCoordLong'),
            'dateStart' => Yii::t('app', 'Date Start'),
            'timeStart' => Yii::t('app', 'Time Start'),
            'endPoint' => Yii::t('app', 'End Point'),
            'endPointDescription' => Yii::t('app', 'End Point'),
            'endPointCoordLat' => Yii::t('app', 'endPointCoordLat'),
            'endPointCoordLong' => Yii::t('app', 'endPointCoordLong'),
            'timeEnd' => Yii::t('app', 'timeEnd'),
            'dateEnd' => Yii::t('app', 'dateEnd'),
            //'typeMovement' => Yii::t('app', 'Type Movement'),
            'isGeoRoute' => Yii::t('app', 'Is Geo Route'),
            'totalWay' => Yii::t('app', 'totalWay'),
            'totalTime' => Yii::t('app', 'totalTime'),
            'content' => Yii::t('app', 'content'),
            'user_id' => Yii::t('app', 'User ID'),
            'date_create' => Yii::t('app', 'Date Create'),
            'kml' => Yii::t('app', 'kml'),
            'parent_id' => Yii::t('app', 'parent_id'),
            'recommendation' => Yii::t('app', 'recommendation'),
            'map_points' => Yii::t('app', 'map_points'),
        ];
    }
    public function getPointstart() {
        return [
            "coordinates" => [ $this->startPointCoordLat, $this->startPointCoordLong],
            "name" => $this->startPoint
        ];
    }
    public function getPointend() {
        return [
            "coordinates" => [ $this->endPointCoordLat, $this->endPointCoordLong],
            "name" => $this->endPoint
        ];
    }
    public function setParams($post) {
        if(isset($post['ZRouter']['days']))
        {
            ZRouterDay::deleteAll(['router_id' => $this->id]);

            foreach ($post['ZRouter']['days'] as $daykey => $day)
            {

                $data = [];
                $data['ZRouterDay'] = $day;
                $ZRouterDay = new ZRouterDay();
                $ZRouterDay->load($data);
                $ZRouterDay->router_id = $this->id;
                if($ZRouterDay->save()) {
                    if(isset($day['objects']))
                    {
                        ZRouterDayObject::deleteAll(['day_id' => $ZRouterDay->id]);

                        foreach ($day['objects'] as $object)
                        {
                            $data = [];
                            $data['ZRouterDayObject'] = $object;
                            $ZRouterDayObject = new ZRouterDayObject();
                            $ZRouterDayObject->load($data);

                            $ZRouterDayObject->day_id = $ZRouterDay->id;
                            if($ZRouterDayObject->save())
                            {

                                if(isset($object['typeMovement']) && is_array($object['typeMovement']))
                                {
                                    ZRouterDayObjectType::deleteAll(['day_object_id' => $ZRouterDayObject->id]);
                                    foreach ($object['typeMovement'] as $typeMovement)
                                    {
                                        $ZRouterDayObjectType = new ZRouterDayObjectType();
                                        $ZRouterDayObjectType->type = $typeMovement;
                                        $ZRouterDayObjectType->day_object_id = $ZRouterDayObject->id;
                                        if($ZRouterDayObjectType->save())
                                        {}
                                        else {
                                            var_dump($ZRouterDayObjectType->getErrors());
                                        }

                                    }
                                }
                            } else {
                                var_dump($ZRouterDayObject->getErrors());exit;
                            }

                        }
                    }
                }else{
                    var_dump($ZRouterDay->getErrors());
                }

            }
        }
        if(isset($post['ZRouter']['objects']))
        {
            ZRouterObject::deleteAll(['router_id' => $this->id]);
            foreach ($post['ZRouter']['objects'] as $object)
            {
                $ZRouterObject = new ZRouterObject();
                $ZRouterObject->object_id = $object['object_id'];
                $ZRouterObject->router_id = $this->id;
                if($ZRouterObject->save()){}
                else{
                    var_dump($ZRouterObject->getErrors());
                }
            }
        }
        if(isset($post['ZRouter']['files']))
        {

            ZRouterFile::deleteAll(['router_id' => $this->id]);
            foreach ($post['ZRouter']['files'] as $file)
            {
                if(isset($file['base64']) && $file['base64'] != '')
                {
                    if (preg_match('/^data:image\/(\w+);base64,/', $file['base64'], $type)) {
                        $data = substr($file['base64'], strpos($file['base64'], ',') + 1);
                        $type = strtolower($type[1]); // jpg, png, gif

                        if (!in_array($type, [ 'jpg', 'jpeg', 'gif', 'png' ])) {
                            throw new \Exception('invalid image type');
                        }
                        $data = str_replace( ' ', '+', $data );
                        $data = base64_decode($data);

                        if ($data === false) {
                            throw new \Exception('base64_decode failed');
                        }
                    } else {
                        throw new \Exception('did not match data URI with image data');
                    }
                    $path = "/uploads/img-".time().rand(10, 100).".{$type}";
                    file_put_contents($_SERVER['DOCUMENT_ROOT'].$path, $data);
                }else {
                    $path = $file['url'];
                }
                $ZRouterFile = new ZRouterFile();
                $ZRouterFile->router_id = $this->id;
                $ZRouterFile->url = $path;
                $ZRouterFile->base64 = '';
                $ZRouterFile->type = $file['type'];
                $ZRouterFile->save();
                if($ZRouterFile->save()) {}else{
                    var_dump($ZRouterFile->getErrors());
                }
            }
        }
        if(isset($post['ZRouter']['typeMovement'])) {
            ZRouterType::deleteAll(['router_id' => $this->id]);
            foreach ($post['ZRouter']['typeMovement'] as $type) {
                $ZRouterType = new ZRouterType();
                $ZRouterType->router_id = $this->id;
                $ZRouterType->type = $type;
                if($ZRouterType->save()) {}else{
                    var_dump($ZRouterType->getErrors());
                }
            }

        }
        if(isset($post['ZRouter']['tags'])) {
            ZRouterTagRelation::deleteAll(['id_router' => $this->id]);
            foreach ($post['ZRouter']['tags'] as $type) {
                $ZRouterTagRelation = new ZRouterTagRelation();
                $ZRouterTagRelation->id_router = $this->id;
                $ZRouterTagRelation->id_tag = $type['id'];
                if($ZRouterTagRelation->save()) {}else{
                    var_dump($ZRouterTagRelation->getErrors());
                }
            }

        }
        if(isset($post['ZRouter']['regions'])) {
            ZRouterRegionRelation::deleteAll(['id_router' => $this->id]);
            foreach ($post['ZRouter']['regions'] as $region) {
                $ZRouterRegionRelation = new ZRouterRegionRelation();
                $ZRouterRegionRelation->id_router = $this->id;
                $ZRouterRegionRelation->id_region = $region['id'];
                if($ZRouterRegionRelation->save()) {}else{
                    var_dump($ZRouterRegionRelation->getErrors());
                }
            }

        }
    }
    public function cloneObject($object, $attributes)
    {
        $cloneObject = clone $object;
        $cloneObject->isNewRecord = true;
        $cloneObject->attributes = $object->attributes;
        foreach ($attributes as $key => $attribute) {
            $cloneObject->$key = $attribute;
        }
        foreach ($object->getPrimaryKey(true) as $field => $value) {
            unset($cloneObject->{$field});
        }
        if($cloneObject->save()){}else{
            var_dump($cloneObject->getErrors());
        }
        return $cloneObject;
    }
    public function cloneParent($parent)
    {
        $objects = ZRouterObject::findAll(['router_id' => $parent->id]);
        foreach ($objects as $child)
        {
            $this->cloneObject($child, ['router_id' => $this->id]);
        }
        $objects = ZRouterFile::findAll(['router_id' => $parent->id]);
        foreach ($objects as $child)
        {
            $this->cloneObject($child, ['router_id' => $this->id]);
        }
        $objects = ZRouterType::findAll(['router_id' => $parent->id]);
        foreach ($objects as $child)
        {
            $this->cloneObject($child, ['router_id' => $this->id]);
        }
        $objects = ZRouterTagRelation::findAll(['id_router' => $parent->id]);
        foreach ($objects as $child)
        {
            $this->cloneObject($child, ['id_router' => $this->id]);
        }
        $objects = ZRouterRegionRelation::findAll(['id_router' => $parent->id]);
        foreach ($objects as $child)
        {
            $this->cloneObject($child, ['id_router' => $this->id]);
        }
        $objects = ZRouterDay::findAll(['router_id' => $parent->id]);
        foreach ($objects as $child)
        {
            $day = $this->cloneObject($child, ['router_id' => $this->id]);
            foreach ($child->objects as $object)
            {

                $objectClone = $this->cloneObject($object, ['day_id' => $day->id, 'object_id' => 0]);
                $objectClone->object_id = $objectClone->id;
                $objectClone->save();

                foreach ($object->types as $type)
                {
                    $this->cloneObject($type, ['day_object_id' => $objectClone->id]);
                }
            }

        }
    }
    public function getData($user_id)
    {
        $result = $this->attributes;

        $result['objects'] = $this->getObjects();
        $result['typesOfMovement'] = $this->getTypemove();
        $result['files'] = $this->getFilesarray();
        $result['pointStart'] = $this->getPointstart();
        $result['pointEnd'] = $this->getPointend();
        $result['days'] = $this->getDaysar();
        $result['tags'] = $this->getTags();
        $result['regions'] = $this->getRegions();
        $result['like'] = $this->getLike($user_id);
        return $result;
    }
    public function getLike($user_id) {
        $ZRouterLike = 0;
        if($user_id)
            $ZRouterLike = ZRouterLike::find()->where(['id_router' => $this->id , 'id_user' => $user_id])->count();



        return $ZRouterLike;
    }
    public function getTypemove() {
        $result = [];
        $ZRouterType = ZRouterType::findAll(['router_id' => $this->id]);
        foreach ($ZRouterType as $item)
        {
            $result[]  = $item->type;
        }
        return $result;
    }
    public function getTags() {
        $result = [];
        $ZRouterTagRelation = ZRouterTagRelation::findAll(['id_router' => $this->id]);
        foreach ($ZRouterTagRelation as $item)
        {
            $result[]  = $item->tag;
        }
        return $result;
    }
    public function getRegions() {
        $result = [];
        $ZRouterRegionRelation = ZRouterRegionRelation::findAll(['id_router' => $this->id]);
        foreach ($ZRouterRegionRelation as $item)
        {
            $result[]  = $item->region;
        }
        return $result;
    }
    public function getDaysar() {
        $ZRouterDay = ZRouterDay::find()->where(['router_id' => $this->id])->all();
        $result = [];
        foreach ($ZRouterDay as $key => $day)
        {
            $result[$key]['id'] = $day->id;
            $result[$key]['pointStart'] = [
                "coordinates" => [$day->startPointCoordLat, $day->startPointCoordLong],
                "name" =>  $day->startPoint,
                "date" =>  $day->dateStart,
                "time" =>  $day->timeStart,
            ];
            $result[$key]['pointEnd'] = [
                "coordinates" => [$day->endPointCoordLat, $day->endPointCoordLong],
                "name" =>  $day->endPoint,
                "date" =>  $day->dateEnd,
                "time" =>  $day->timeEnd,
            ];
            $result[$key]['objects'] =  [];

            foreach ($day->objects as $objectKey => $object)
            {

                $result[$key]['objects'][$objectKey] = $object->attributes;
                $result[$key]['objects'][$objectKey]["coordinates"] = [$object->startPointCoordLat, $object->startPointCoordLong];
                $result[$key]['objects'][$objectKey]["images"] = [];
                if($object['object_id'] !=  null)
                {
                    $ZBrandPhoto = ZBrandPhoto::findAll(['brand_id' => $object['object_id']]);
                    foreach ($ZBrandPhoto as $image)
                        $result[$key]['objects'][$objectKey]["images"][] = ZRouter::PATHIMAGE.$image['id'].'.jpg';

                }
                if($object->types)
                    foreach ($object->types as $typeKey => $type)
                    {

                        $result[$key]['objects'][$objectKey]['typeMovement'][$typeKey] = $type->type;
                    }
                //$result[$key]['objects'][$objectKey]['tag'] = ZBrandTagType::find()->select(['name'])->where(['brand_id' => $object['object_id']])->all();
            }
        }
        
        return $result;
    }
   /* public function getObjects() {
        $result = [];
        $ZRouterObject = ZRouterObject::findAll(['router_id' => $this->id]);
        foreach ($ZRouterObject as $object)
        {
            $objectAr  = ZBrand::find()->select(['id', 'name', 'block1 as description', 'type', 'position'])->where(['id' => $object->object_id])->asArray()->one();
            $resultAr = [];
            $resultAr = $objectAr;

            $ZBrandRegion = ZBrandRegion::findOne(['brand_id' => $object->object_id]);
            if($ZBrandRegion)
            {
                $resultAr['region'] = $ZBrandRegion->region_id;
            }
            $ZBrandPhoto = ZBrandPhoto::findAll(['brand_id' => $object['id']]);
            foreach($ZBrandPhoto as $image)
            {
                $resultAr['images'][] = ZRouter::PATHIMAGE.$image['id'].'.jpg';
            }

            //$resultAr['tag'] = ZBrandTagType::find()->select(['name'])->where(['brand_id' =>$object->object_id])->all();
            $result[] = $resultAr;
        }
        return $result;
    }*/
    public function getObjects() {
        $result = [];
        $ZRouterObject = ZRouterObject::findAll(['router_id' => $this->id]);
        foreach ($ZRouterObject as $object)
        {
            $objectAr  = ZBrandObject::find()->where(['id' => $object->object_id])->asArray()->one();
            if($objectAr)
            {
                $resultAr = [];
                $resultAr = $objectAr;
                $ZBrandObjectRelation = ZBrandObjectRelation::find()->select(['brand_id'])->where(['object_id' => $object->object_id]);

                    $ZBrandRegion = ZBrandRegion::findOne(['brand_id' => $ZBrandObjectRelation]);
                    if($ZBrandRegion)
                    {
                        $resultAr['region'] = $ZBrandRegion->region_id;
                    }

                $resultAr['position'] = $objectAr['lat'].', '.$objectAr['long'];
                $result[] = $resultAr;
            }

        }
        return $result;
    }

    public function getFiles()
    {
        return $this->hasMany(ZRouterFile::className(), ['router_id' => 'id']);
    }
    public function getFilesarray()
    {
        return $this->hasMany(ZRouterFile::className(), ['router_id' => 'id'])->asArray()->all();
    }
    public function getDays()
    {
        return $this->hasMany(ZRouterDay::className(), ['router_id' => 'id']);
    }
    public function curl_get_contents($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }
}
