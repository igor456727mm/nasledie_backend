<?php

namespace app\models;

use Yii;
use app\models\ZRouter;
/**
 * This is the model class for table "z_router_file".
 *
 * @property int $id
 * @property string|null $url
 * @property string|null $base64
 * @property string $type
 * @property int $router_id
 */
class ZRouterFile extends \yii\db\ActiveRecord
{
    const TYPE_IMAGE = 'image';
    const TYPE_VIDEO = 'video';
    const TYPE_DOC = 'doc';
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_file';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['base64'], 'string'],
            [['type', 'router_id'], 'required'],
            [['router_id'], 'default', 'value' => null],
            [['router_id'], 'integer'],
            [['url', 'type'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'url' => Yii::t('app', 'Url'),
            'base64' => Yii::t('app', 'Base64'),
            'type' => Yii::t('app', 'Type'),
            'router_id' => Yii::t('app', 'Router ID'),
        ];
    }


    public function getRouter()
    {
        return $this->hasOne(ZRouter::className(), ['id' => 'router_id']);
    }
}
