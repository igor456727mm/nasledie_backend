<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_router_ball".
 *
 * @property int $id
 * @property int $router_id
 * @property int $ball_id
 */
class ZRouterBall extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_ball';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'router_id', 'ball_id'], 'required'],
            [['id', 'router_id', 'ball_id'], 'default', 'value' => null],
            [['id', 'router_id', 'ball_id'], 'integer'],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'router_id' => Yii::t('app', 'Router ID'),
            'ball_id' => Yii::t('app', 'Ball ID'),
        ];
    }
}
