<?php

namespace app\models;

use Yii;
use app\models\ZRouterTag;
/**
 * This is the model class for table "z_router_tag_relation".
 *
 * @property int $id
 * @property int $id_router
 * @property int $id_tag
 */
class ZRouterTagRelation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_tag_relation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_router', 'id_tag'], 'required'],
            [['id_router', 'id_tag'], 'default', 'value' => null],
            [['id_router', 'id_tag'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'id_router' => Yii::t('app', 'Id Router'),
            'id_tag' => Yii::t('app', 'Id Tag'),
        ];
    }
    public function getTag()
    {
        return $this->hasOne(ZRouterTag::className(), ['id' => 'id_tag']);
    }
}
