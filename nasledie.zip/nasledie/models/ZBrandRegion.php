<?php

namespace app\models;

use Yii;
use app\models\ZRegion;
/**
 * This is the model class for table "z_brand_region".
 *
 * @property int|null $brand_id
 * @property int|null $region_id
 */
class ZBrandRegion extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_region';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['brand_id', 'region_id'], 'default', 'value' => null],
            [['brand_id', 'region_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'brand_id' => Yii::t('app', 'Brand ID'),
            'region_id' => Yii::t('app', 'Region ID'),
        ];
    }
    public function getRegion()
    {
        return $this->hasOne(ZRegion::className(), ['region_id' => 'id']);
    }
}
