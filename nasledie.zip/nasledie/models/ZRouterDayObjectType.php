<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_router_day_object_type".
 *
 * @property int $id
 * @property string|null $type
 * @property int $day_object_id
 */
class ZRouterDayObjectType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_day_object_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['day_object_id'], 'required'],
            [['day_object_id'], 'default', 'value' => null],
            [['day_object_id'], 'integer'],
            [['type'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type' => Yii::t('app', 'Type'),
            'day_object_id' => Yii::t('app', 'Day Object ID'),
        ];
    }
}
