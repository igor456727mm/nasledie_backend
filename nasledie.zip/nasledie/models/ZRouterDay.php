<?php

namespace app\models;

use Yii;
use app\models\ZRouter;
use app\models\ZRouterDayObjectType;

/**
 * This is the model class for table "z_router_day".
 *
 * @property int $id
 * @property string|null $name
 * @property string|null $startPoint
 * @property float|null $startPointCoordLat
 * @property float|null $startPointCoordLong
 * @property string|null $dateStart
 * @property string|null $timeStart
 * @property string|null $endPoint
 * @property float|null $endPointCoordLat
 * @property float|null $endPointCoordLong
 * @property string|null $dateEnd
 * @property string|null $timeEnd
 * @property int $router_id
 */
class ZRouterDay extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_day';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['startPointCoordLat', 'startPointCoordLong', 'endPointCoordLat', 'endPointCoordLong'], 'safe'],
            [['router_id'], 'required'],
            [['router_id'], 'default', 'value' => null],
            [['router_id'], 'integer'],
            [['name', 'startPoint', 'dateStart', 'timeStart', 'endPoint', 'dateEnd', 'timeEnd', 'neededTimeEnd'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'startPoint' => Yii::t('app', 'Start Point'),
            'startPointCoordLat' => Yii::t('app', 'Start Point Coord Lat'),
            'startPointCoordLong' => Yii::t('app', 'Start Point Coord Long'),
            'dateStart' => Yii::t('app', 'Date Start'),
            'timeStart' => Yii::t('app', 'Time Start'),
            'endPoint' => Yii::t('app', 'End Point'),
            'endPointCoordLat' => Yii::t('app', 'End Point Coord Lat'),
            'endPointCoordLong' => Yii::t('app', 'End Point Coord Long'),
            'dateEnd' => Yii::t('app', 'Date End'),
            'timeEnd' => Yii::t('app', 'Time End'),
            'router_id' => Yii::t('app', 'Router ID'),
            'neededTimeEnd' => Yii::t('app', 'neededTimeEnd'),
        ];
    }

    public function getRouter()
    {
        return $this->hasOne(ZRouter::className(), ['id' => 'router_id']);
    }

    public function getObjects()
    {
        return $this->hasMany(ZRouterDayObject::className(), ['day_id' => 'id']);
    }
}
