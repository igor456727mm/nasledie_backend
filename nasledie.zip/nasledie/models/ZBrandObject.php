<?php

namespace app\models;

use Yii;
use app\models\ZBrand;
/**
 * This is the model class for table "z_brand_object".
 *
 * @property int $id
 * @property string|null $name
 * @property string|null $short_description
 * @property string|null $description
 * @property float|null $lat
 * @property float|null $long
 * @property int $brand_id
 * @property string|null $image
 * @property int $user_id
 * @property string $date_create
 */
class ZBrandObject extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_object';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['short_description', 'description'], 'string'],
            [['lat', 'long'], 'number'],
            [[ 'user_id', 'date_create'], 'required'],
            [[ 'user_id'], 'default', 'value' => null],
            [[ 'user_id'], 'integer'],
            [['date_create'], 'safe'],
            [['name', 'image'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'short_description' => Yii::t('app', 'Short Description'),
            'description' => Yii::t('app', 'Description'),
            'lat' => Yii::t('app', 'Lat'),
            'long' => Yii::t('app', 'Long'),

            'image' => Yii::t('app', 'Image'),
            'user_id' => Yii::t('app', 'User ID'),
            'date_create' => Yii::t('app', 'Date Create'),
        ];
    }
}
