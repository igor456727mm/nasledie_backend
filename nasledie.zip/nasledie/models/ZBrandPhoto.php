<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_photo".
 *
 * @property int $id
 * @property int|null $brand_id
 * @property string|null $title
 * @property string|null $dttm
 * @property string|null $author_name
 * @property string|null $license
 * @property string|null $photo_source
 */
class ZBrandPhoto extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_photo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['brand_id'], 'default', 'value' => null],
            [['brand_id'], 'integer'],
            [['dttm'], 'safe'],
            [['title', 'photo_source'], 'string', 'max' => 1000],
            [['author_name', 'license'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'brand_id' => Yii::t('app', 'Brand ID'),
            'title' => Yii::t('app', 'Title'),
            'dttm' => Yii::t('app', 'Dttm'),
            'author_name' => Yii::t('app', 'Author Name'),
            'license' => Yii::t('app', 'License'),
            'photo_source' => Yii::t('app', 'Photo Source'),
        ];
    }
}
