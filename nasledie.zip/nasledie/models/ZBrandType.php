<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_type".
 *
 * @property string $id
 * @property string|null $caption
 * @property string|null $css_alias
 * @property string|null $caption_import
 */
class ZBrandType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id'], 'required'],
            [['id'], 'string', 'max' => 40],
            [['caption', 'css_alias'], 'string', 'max' => 200],
            [['caption_import'], 'string', 'max' => 100],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'caption' => Yii::t('app', 'Caption'),
            'css_alias' => Yii::t('app', 'Css Alias'),
            'caption_import' => Yii::t('app', 'Caption Import'),
        ];
    }
}
