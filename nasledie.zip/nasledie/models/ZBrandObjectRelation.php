<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_object_relation".
 *
 * @property int $id
 * @property int $brand_id
 * @property int $object_id
 */
class ZBrandObjectRelation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_object_relation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['brand_id', 'object_id'], 'required'],
            [['brand_id', 'object_id'], 'default', 'value' => null],
            [['brand_id', 'object_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'brand_id' => Yii::t('app', 'Brand ID'),
            'object_id' => Yii::t('app', 'Object ID'),
        ];
    }
}
