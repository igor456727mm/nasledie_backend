<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_ball".
 *
 * @property int $brand_id
 * @property int $user_id
 * @property int $ball_id
 * @property string $date
 */
class ZBrandBall extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_ball';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['brand_id', 'user_id', 'ball_id', 'date'], 'required'],
            [['brand_id', 'user_id', 'ball_id'], 'default', 'value' => null],
            [['brand_id', 'user_id', 'ball_id'], 'integer'],
            [['date'], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'brand_id' => Yii::t('app', 'Brand ID'),
            'user_id' => Yii::t('app', 'User ID'),
            'ball_id' => Yii::t('app', 'Ball ID'),
            'date' => Yii::t('app', 'Date'),
        ];
    }
}
