<?php

namespace app\models;

use Yii;
use app\models\ZBrand;
/**
 * This is the model class for table "z_router_object".
 *
 * @property int $id
 * @property int $object_id
 * @property int $router_id
 */
class ZRouterObject extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_router_object';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['object_id', 'router_id'], 'required'],
            [['object_id', 'router_id'], 'default', 'value' => null],
            [['object_id', 'router_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'object_id' => Yii::t('app', 'Object ID'),
            'router_id' => Yii::t('app', 'Router ID'),

        ];
    }
    public function getObject()
    {
        return $this->hasOne(ZBrand::className(), ['object_id' => 'id']);
    }
}
