<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "z_brand_request".
 *
 * @property int $id
 * @property string|null $dttm
 * @property int|null $user_fk
 * @property int|null $request_status_fk
 * @property string|null $request_data
 * @property int|null $user_moderator_fk
 * @property int|null $user_admin_fk
 * @property int|null $brand_fk
 *
 * @property ZBrand $brandFk
 * @property ZBrandRequestStatus $requestStatusFk
 * @property ZUser $userModeratorFk
 * @property ZUser $userAdminFk
 */
class ZBrandRequest extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'z_brand_request';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['dttm', 'request_data'], 'safe'],
            [['user_fk', 'request_status_fk', 'user_moderator_fk', 'user_admin_fk', 'brand_fk'], 'default', 'value' => null],
            [['user_fk', 'request_status_fk', 'user_moderator_fk', 'user_admin_fk', 'brand_fk'], 'integer'],
            [['brand_fk'], 'exist', 'skipOnError' => true, 'targetClass' => ZBrand::className(), 'targetAttribute' => ['brand_fk' => 'id']],
            [['request_status_fk'], 'exist', 'skipOnError' => true, 'targetClass' => ZBrandRequestStatus::className(), 'targetAttribute' => ['request_status_fk' => 'id']],
            [['user_moderator_fk'], 'exist', 'skipOnError' => true, 'targetClass' => ZUser::className(), 'targetAttribute' => ['user_moderator_fk' => 'id']],
            [['user_admin_fk'], 'exist', 'skipOnError' => true, 'targetClass' => ZUser::className(), 'targetAttribute' => ['user_admin_fk' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'dttm' => Yii::t('app', 'Dttm'),
            'user_fk' => Yii::t('app', 'User Fk'),
            'request_status_fk' => Yii::t('app', 'Request Status Fk'),
            'request_data' => Yii::t('app', 'Request Data'),
            'user_moderator_fk' => Yii::t('app', 'User Moderator Fk'),
            'user_admin_fk' => Yii::t('app', 'User Admin Fk'),
            'brand_fk' => Yii::t('app', 'Brand Fk'),
        ];
    }

    /**
     * Gets query for [[BrandFk]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBrandFk()
    {
        return $this->hasOne(ZBrand::className(), ['id' => 'brand_fk']);
    }

    /**
     * Gets query for [[RequestStatusFk]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRequestStatusFk()
    {
        return $this->hasOne(ZBrandRequestStatus::className(), ['id' => 'request_status_fk']);
    }

    /**
     * Gets query for [[UserModeratorFk]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUserModeratorFk()
    {
        return $this->hasOne(ZUser::className(), ['id' => 'user_moderator_fk']);
    }

    /**
     * Gets query for [[UserAdminFk]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUserAdminFk()
    {
        return $this->hasOne(ZUser::className(), ['id' => 'user_admin_fk']);
    }
}
