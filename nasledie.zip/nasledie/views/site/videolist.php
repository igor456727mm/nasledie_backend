
<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Обучение видео</h1>

        <p class="lead">Материалы представлены в ознакомительных целях.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Начать просмотр</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Акушерство и гинекология</h2>
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/v64KOxKVLVg" allowfullscreen></iframe>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/doc/">Начать просмотр &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Вирусология и вирусы в организме</h2>
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/v64KOxKVLVg" allowfullscreen></iframe>
                <p><a class="btn btn-default btn-success" href="http://www.yiiframework.com/forum/">Начать просмотр &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Гигиена детей и подростков</h2>

                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/v64KOxKVLVg" allowfullscreen></iframe>
                <p><a class="btn btn-default" href="http://www.yiiframework.com/extensions/">Начать просмотр &raquo;</a></p>
            </div>
        </div>

    </div>
</div>

