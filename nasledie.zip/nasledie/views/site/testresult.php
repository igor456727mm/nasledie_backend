<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Результаты тестиирования </h1>

        <p class="lead">Пройдено тестирование персонала по теме "Гигиена детей и подростков". Оценка прохождения 5</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Начать заново</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Вопросы</th>
                    <th>Кол-во ответов</th>
                    <th>Ответ правельный</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>1</td>
                    <td>Государственная санитарно-эпидемиологическая служба-это</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Индикатором развития общества в социальном, духовном и культурном плане, в первую очередь, является:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Социально-экономическое состояние страны и развитие здравоохранения, особенно, отражает:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Для демографической ситуации в России характерно</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Показателями общественного здоровья являются все перечисленное, кроме:</td>
                    <td>4</td>
                    <td><code class="green">Да</code> </td>
                </tr>
                </tbody>
            </table>
        </div>

    </div>
</div>
