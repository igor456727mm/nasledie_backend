<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Тестирование персонала</h1>

        <p class="lead">Тестирование персонала по ключевым навыкам.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Начать</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Акушерство и гинекология</h2>

                <p>система органов, учреждений и предприятий, независимо от их подчиненности, осуществляющих мероприятия по сохранению и укреплению здоровья людей и профилактике заболеваний человека</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/doc/">Начать тест &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Вирусология и вирусы в организме</h2>

                <p>система органов, учреждений и предприятий, независимо от их подчиненности, осуществляющих мероприятия по сохранению и укреплению здоровья людей и профилактике заболеваний человека</p>

                <p><a class="btn btn-default btn-success" href="http://www.yiiframework.com/forum/">Продолжить тест &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Гигиена детей и подростков</h2>

                <p>система органов, учреждений и предприятий, независимо от их подчиненности, осуществляющих мероприятия по сохранению и укреплению здоровья людей и профилактике заболеваний человека</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/extensions/">Начать тест &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
