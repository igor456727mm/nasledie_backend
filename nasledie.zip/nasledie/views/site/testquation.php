<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Вопрос № 3 </h1>

        <p class="lead">Социально-экономическое состояние страны и развитие здравоохранения, особенно, отражает:</p>

    </div>

    <div class="body-content">

        <div class="row">
            <div class="form-group">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                    <label class="form-check-label" for="inlineCheckbox1">младенческая смертность</label>
                </div>
            </div>
            <div class="form-group">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                <label class="form-check-label" for="inlineCheckbox2">физическое развитие детей и подростков</label>
            </div>
            </div><div class="form-group">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                <label class="form-check-label" for="inlineCheckbox2">уровень хронической заболеваемости детского населения</label>
            </div>
            </div><div class="form-group">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                <label class="form-check-label" for="inlineCheckbox2">заболеваемость детей до 1 года</label>
            </div>
            </div><div class="form-group">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                <label class="form-check-label" for="inlineCheckbox2">показатели инвалидности с детства</label>
            </div>
            </div>
            <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Ответить</a></p>

        </div>
</div>
