<?
if(@$_COOKIE['SESSID']) {
            session_id($_COOKIE['SESSID']);
			session_start();
}
var_dump(@$_SESSION);
?>