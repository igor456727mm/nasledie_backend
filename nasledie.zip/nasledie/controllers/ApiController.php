<?php

namespace app\controllers;

use app\models\ZRouterDay;
use app\models\ZRouterDayObject;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\helpers\Json;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\ZRegion;
use app\models\ZBrandType;
use app\models\ZBall;
use app\models\ZBrandBall;
use app\models\ZBrand;
use app\models\ZBrandObject;
use app\models\ZBrandObjectRelation;
use app\models\ZBrandTagType;
use app\models\ZRouterLike;
use app\models\ZRouterRegion;
use app\models\ZRouterRegionRelation;
use app\models\ZRouterTag;
use app\models\ZRouterTagRelation;
use app\models\ZBrandRegion;
use app\models\ZRouterObject;
use app\models\ZRouter;
use app\models\ZRouterType;
use app\models\ZRouterFile;
use app\models\ZBrandPhoto;
use yii\helpers\ArrayHelper;


class ApiController extends Controller
{
    public $enableCsrfValidation = false;
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }
    public function beforeAction($action)
    {

        \Yii::$app->response->format = Response::FORMAT_JSON;
        return parent::beforeAction($action);
    }
    public function actionTest()
    {
       
    }
    public function actionBall()
    {
        /*$ZBall = new ZBall();
        $ZBall->id = 1;
        $ZBall->name = 'Создание бренда';
        $ZBall->description = 'Условие выполняется, если пользователь создает бренд';
        $ZBall->ball = 10;
        $ZBall->status = 1;
        $ZBall->code = 'router_create';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 2;
        $ZBall->name = 'Редактирование бренда';
        $ZBall->description = 'Условие выполняется, если пользователь редактирует бренд';
        $ZBall->ball = 5;
        $ZBall->status = 1;
        $ZBall->code = 'router_edit';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 3;
        $ZBall->name = 'Добавление в избранное';
        $ZBall->description = 'Условие выполняется, если пользователь добавил бренд в избранное';
        $ZBall->ball = 1;
        $ZBall->status = 1;
        $ZBall->code = 'favorite';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 4;
        $ZBall->name = 'Добавление оценки';
        $ZBall->description = 'Условие выполняется, если пользователь добавил оценку бренду';
        $ZBall->ball = 1;
        $ZBall->status = 1;
        $ZBall->code = 'appraisal';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 5;
        $ZBall->name = 'Добавление комментария';
        $ZBall->description = 'Условие выполняется, если пользователь добавил комментария бренду';
        $ZBall->ball = 2;
        $ZBall->status = 1;
        $ZBall->code = 'comment';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 6;
        $ZBall->name = 'Добавление "я тут был"';
        $ZBall->description = 'Условие выполняется, если пользователь отметился "я тут был"';
        $ZBall->ball = 1;
        $ZBall->status = 1;
        $ZBall->code = 'comment';
        $ZBall->save();
        $ZBall = new ZBall();
        $ZBall->id = 7;
        $ZBall->name = 'Время на сайте';
        $ZBall->description = 'Условие выполняется, при расчете за 1 час';
        $ZBall->ball = 1;
        $ZBall->status = 1;
        $ZBall->code = 'time';
        $ZBall->save();
        */


        $res = ZBall::find()->asArray()->all();
        var_dump($res);
    }
    public function actionList($user_id)
    {
        return $this->routerList(0, $user_id);
    }
    public function actionListrec($user_id)
    {
        return $this->routerList(1, $user_id);
    }
    public function actionRouterget($id, $user_id)
    {
        return $this->routerGet($id, $user_id);
    }
    public function actionRouteredit($id, $user_id)
    {
        return $this->routerSave($id, $user_id);
    }
    public function actionRouter($user_id)
    {
        return $this->routerSave(null, $user_id);
    }

    public function actionRouterdelete($id, $user_id)
    {
        $ZRouter = ZRouter::findOne(['id' => $id]);
        if($ZRouter)
        {
            $like = ZRouterLike::findOne(['id_user'=> $user_id, 'id_router' => $ZRouter->parent_id]);
            if($like){
                $like->delete();
            }
            $ZRouter->delete();
            $result = ['status' => true];
        }else{
            $result = ['status' => false];
        }
        return Json::encode($result);
    }

    public function actionRegion()
    {
        $ar = ZRegion::find()->select(['id as value', 'name'])->asArray()->all();
        return Json::encode($ar);
    }
    public function actionType()
    {
        $ar = ZBrandType::find()->select(['id as value', 'caption as name'])->asArray()->all();
        return Json::encode($ar);
    }
    public function actionObjectradius()
    {
        $radius = 1;
        $brands = ZBrandObject::find()->asArray()->all();
        $result = [];
        $i = 0;
        $post = Yii::$app->request->post();
        $post['coordinates'] = json_decode($post['coordinates']);
        $repeat = [];
        if(isset($post['coordinates']))
            foreach ($brands as $key => $object)
            {
                $pointLat = $object['lat'];
                $pointLong = $object['long'];

                foreach ($post['coordinates'] as $cordKey => $coordinate)
                {
                    $lat = $coordinate[0];
                    $long = $coordinate[1];
                    $xxx =  pow($pointLat - $lat, 2) + pow($pointLong - $long, 2);
                    if($xxx <= 0.6)
                    {
                        if(in_array($object['id'], $repeat)) continue;
                        $repeat[] = $object['id'];
                        $result[$i] = $object;
                        $ZBrandRegion = ZBrandRegion::findOne(['brand_id' => $object['id']]);
                        if($ZBrandRegion)
                        {
                            $result[$i]['region'] = $ZBrandRegion->region_id;
                        }

                        $result[$i]['position'] = $object['lat'].', '.$object['long'];
                        $ZBrandObjectRelation = ZBrandObjectRelation::find()->select(['brand_id'])->where(['object_id' => $object['id']]);
                        if($ZBrandObjectRelation)
                        {
                            $ZBrands = ZBrand::find()->select(['id','name','type'])->where(['in', 'id', $ZBrandObjectRelation])->asArray()->all();
                            if(count($ZBrands) > 0 )
                            {

                                $result[$i]['brandid'] = $ZBrands[0]['id'];
                                $result[$i]['brandname'] = $ZBrands[0]['name'];
                                $result[$i]['type'] = $ZBrands[0]['type'];
                            }

                        }


                        $i++;
                        //break;
                    }
                }

            }
        else if(is_array($post['coordinates'])) {
            $result = ['status' => false, 'description' => 'Массив координат не передан'];
        }else {
            $result = ['status' => false, 'description' => 'Это не массив '];
        }

        return Json::encode($result);
    }
    /*public function actionObject($type = null, $region = null, $query  = null)
    {

        $ar = ZBrand::find()->select(['id', 'name', 'block1 as description', 'type', 'position' ]);

        $ZRouter = new ZRouter();
        if($type)
        {
            $ar = $ar->where(['type' => $type]);
        }
        if($query)
        {

            $ar = $ar->andwhere(['like', 'LOWER(name)', mb_strtolower($query)]);
        }
        if($region)
        {
            $ZBrandRegion = ZBrandRegion::find()->select(['brand_id'])->where(['region_id' => $region])->column();

            $ar->andwhere(['in', 'id', $ZBrandRegion]);
        }
        $ar = $ar->asArray()->limit(10)->all();
        //$arObject = [];
        foreach ($ar as  $key => $item)
        {
            $ZBrandRegion = ZBrandRegion::findOne(['brand_id' => $item['id']]);
            if($ZBrandRegion)
            {
                $ar[$key]['region'] = $ZBrandRegion->region_id;
            }
            $ZBrandPhoto = ZBrandPhoto::findAll(['brand_id' => $item['id']]);
            foreach($ZBrandPhoto as $image)
            {


                $ar[$key]['images'][] = ZRouter::PATHIMAGE.$image['id'].'.jpg';
            }
            //$ar[$key]['tags'] = ArrayHelper::map(ZBrandTagType::find()->where(['brand_id' => $item['id']])->all(), 'id', 'name');
        }
        return Json::encode($ar);
    }*/
    public function actionObject($type = null, $region = null, $query  = null)
    {


        /*
        $ZBrandObjectRelation = new ZBrandObjectRelation();
        $ZBrandObjectRelation->object_id = 31;
        $ZBrandObjectRelation->brand_id = 407;
        $ZBrandObjectRelation->save();

        $ZBrandObjectRelation = new ZBrandObjectRelation();
        $ZBrandObjectRelation->object_id = 32;
        $ZBrandObjectRelation->brand_id = 689;
        $ZBrandObjectRelation->save();
        $ZBrandObject = new ZBrandObject();
        $ZBrandObject->name = 'Объект по бренду Нальчик';
        $ZBrandObject->description = 'Нальчик - редкий пример организации человеческого общежития';
        $ZBrandObject->short_description = 'Нальчик - редкий пример ';
        $ZBrandObject->brand_id = 407;
        $ZBrandObject->image = '/uploads/img-160052017842.jpeg';
        $ZBrandObject->lat = 64.537070;
        $ZBrandObject->long = 40.431422;
        $ZBrandObject->user_id = 1;
        $ZBrandObject->date_create = date('Y-m-d H:i:s');
        $ZBrandObject->save();

        //ZBrandObject::deleteAll(['brand_id' => 689]);
        $ZBrandObject = ZBrandObject::find()->all();
        echo '<pre>'; var_dump($ZBrandObject);exit;*/

        $ar = ZBrand::find()->select(['id', 'name', 'type']);

        $ZRouter = new ZRouter();
        if($type)
        {
            $ar = $ar->where(['type' => $type]);
        }

        if($region)
        {
            $ZBrandRegion = ZBrandRegion::find()->select(['brand_id'])->where(['region_id' => $region])->column();

            $ar->andwhere(['in', 'id', $ZBrandRegion]);
        }
        if($query)
        {
            $ar = $ar->andwhere(['like', 'LOWER(name)', mb_strtolower($query)]);
        }
        $ar = $ar->asArray()->limit(10)->all();
        //$arObject = [];
        foreach ($ar as  $key => $item)
        {
            $ZBrandRegion = ZBrandRegion::findOne(['brand_id' => $item['id']]);
            if($ZBrandRegion)
            {
                $ar[$key]['region'] = $ZBrandRegion->region_id;
            }
            $ZBrandObjectRelation = ZBrandObjectRelation::find()->select(['object_id'])->where(['brand_id' => $item['id']]);
            $ZBrandObject = ZBrandObject::find()->where(['in', 'id', $ZBrandObjectRelation])->all();

            $arObject = [];
            $i = 0;
            foreach ($ZBrandObject as $keyObject => $Object)
            {
                $arObject[$i] = $Object->attributes;
                $arObject[$i]['region'] =  $ar[$key]['region'];
                $arObject[$i]['type'] = $item['type'];
                $arObject[$i]['position'] = $Object['lat'].', '.$Object['long'];
                $i++;
            }
            $ar[$key]['objects'] = $arObject;
        }
        

        return Json::encode($ar);
    }

    public function actionRouterlike()
    {
        $post = Yii::$app->request->post();

        $ZRouterLike = new ZRouterLike();
        $ZRouterLike->id_user = $post['id_user'];
        $ZRouterLike->id_router = $post['id_router'];
        if($ZRouterLike->save()){}else{
            var_dump($ZRouterLike->getErrors());
        }

        $ZRouter = ZRouter::findOne(['id' => $post['id_router']]);
        if($ZRouter)
        {
            $newZrouter = clone $ZRouter;
            $newZrouter->attributes = $ZRouter->attributes;
            foreach ($ZRouter->getPrimaryKey(true) as $field => $value) {
                unset($newZrouter->{$field});
            }
            $newZrouter->isNewRecord = true;
            $newZrouter->parent_id = $ZRouter->id;
            $newZrouter->recommendation = 0;
            $newZrouter->user_id = $post['id_user'];
            $newZrouter->date_create = date('Y-m-d H:i:s');
            if($newZrouter->save())
            {
                $newZrouter->cloneParent($ZRouter);
            }else{
                var_dump($newZrouter->getErrors());
            }
            
        }
        return Json::encode(['status' => true]);
    }
    public function actionTag()
    {
       $tags = ZRouterTag::find()->asArray()->all();
       return Json::encode($tags);
    }
    public function actionTagcreate()
    {
        $post = Yii::$app->request->post();
        $post['ZRouterTag'] = json_decode($post['ZRouterTag'], true, 512, JSON_UNESCAPED_UNICODE);
        $ZRouterTag = new ZRouterTag();
        $ZRouterTag->load($post);
        if($ZRouterTag->save())
        {
            $result = ['status' => true, 'id' => $ZRouterTag->id];
        }else{
            $result = ['status' => false, 'description' => $ZRouterTag->errors];
        }
       return Json::encode($result);
    }
    public function routerList($rec = 0, $user_id)
    {

        if($rec == 0 )
            $routers = ZRouter::find()->where(['user_id' => $user_id, 'recommendation' => 0])->orderBy(['id' => SORT_DESC])->all();
        else{
            $routers = ZRouter::find()->where(['recommendation' => 1]);
            $post = Yii::$app->request->post();
            if(isset($post['regions']) && $post['regions'] != '')
            {
                $ids = explode(',', $post['regions']);
                $ids = ZRouterRegionRelation::find()->select(['id_router'])->where(['in', 'id_region', $ids]);
                $routers  = $routers->andwhere(['in', 'id', $ids]);
            }
            //var_dump($post);exit;
            if(isset($post['tags']) && $post['tags'] != '')
            {
                $ids = explode(',', $post['tags']);
                $ids = ZRouterTagRelation::find()->select(['id_router'])->where(['in', 'id_tag', $post['tags']]);
                $routers  = $routers->andwhere(['in', 'id', $ids]);
            }
            if(isset($post['typesOfMovement']) && $post['typesOfMovement'] != ''   )
            {
                $ids = explode(',', $post['typesOfMovement']);
                $ids = ZRouterType::find()->select(['router_id'])->where(['in', 'type', $ids]);
                $routers  = $routers->andwhere(['in', 'id', $ids]);
            }


            $routers  = $routers->orderBy(['id' => SORT_DESC])->all();
        }

        $result = [];
        foreach ($routers as $key => $router)
        {
            $result[$key] = $router->getData($user_id);
        }

        return Json::encode($result);
    }
    public function routerGet($id = null, $user_id)
    {
        $ZRouter = ZRouter::findOne(['id' => $id]);
        if($ZRouter)
        {
            $ZRouterAttr = $ZRouter->getData($user_id);
            $result = ['status' => true, 'router' => $ZRouterAttr];
        }else{
            $result = ['status' => false];
        }
        return Json::encode($result);
    }
    public function routerSave($id = null, $user_id)
    {
        if($id)
            $ZRouter = ZRouter::findOne(['id' => $id]);
        else
            $ZRouter = new ZRouter();

        $post = Yii::$app->request->post();
        $post['ZRouter'] = json_decode($post['ZRouter'], true, 512, JSON_UNESCAPED_UNICODE);
       // var_dump($post['ZRouter']['days'][0]['objects']);exit;
        //$post['objects'] = (isset($post['objects']) ? json_decode($post['objects'], true, 512, JSON_UNESCAPED_UNICODE) : []);
        $ZRouter->load($post);
        $ZRouter->isGeoRoute = ($ZRouter->isGeoRoute == 'Yes' ? 1 : 0);
        $ZRouter->date_create = date('Y-m-d H:i:s');
        if( $ZRouter->save())
        {
            $ZRouter->setParams($post);
            $result = ['status' => true, 'id' => $ZRouter->id];
        }else {
            $result = ['status' => false, 'description' => $ZRouter->errors];
        }
        $ZBrandBall = new ZBrandBall();

        if($id)
        {
            $ZBrandBall->ball_id = 2;
        }else{
            $ZBrandBall->ball_id = 1;
        }
        $ZBrandBall->user_id = $user_id;
        $ZBrandBall->brand_id = $ZRouter->id;
        $ZBrandBall->date = date('Y-m-d H:i:s');
        $ZBrandBall->save();
        return Json::encode($result);
    }
}
